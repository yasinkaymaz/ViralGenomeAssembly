package picard.illumina.parser.readers;

/**
 * Created by IntelliJ IDEA.
 * User: jburke
 * Date: 12/29/11
 * Time: 2:42 PM
 * To change this template use File | Settings | File Templates.
 */
public class IlluminaFileUtilTest {
}
